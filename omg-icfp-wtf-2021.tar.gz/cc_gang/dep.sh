sudo apt-get install libsdl2-dev libcurl4-openssl-dev
