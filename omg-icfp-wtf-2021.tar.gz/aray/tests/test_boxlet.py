#!/usr/bin/env python3
# test_problem.py

import unittest
from dataclasses import asdict
from aray.boxlet import Boxlet, Point, BoundingBox



if __name__ == '__main__':
    unittest.main()
